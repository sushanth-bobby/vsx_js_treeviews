class CircularArray {
    constructor(items) {
      this.items = items;
      this.currentIndex = 0;
    }
  
    next(item) {
      this.currentIndex = this.items.indexOf(item);
      // console.log(this.currentIndex, this.items.length)
      this.currentIndex = this.currentIndex+1 == this.items.length ? 0 : this.currentIndex + 1
      item = this.items[this.currentIndex];    
      // this.currentIndex = (this.currentIndex + 1) % this.items.length;
      return item;
    }
}  
  
// Function to update the status in JSON recursively
function updateStatus(jsonArray, circularArray) {    
    jsonArray.forEach(item => {
      if (item.hasOwnProperty('status')) {        
          // console.log(`${item.label} - ${item.status}`)
          item.status = circularArray.next(item.status);
          // console.log(`- ${item.status}`)        
      }
      if (item.hasOwnProperty('children')) {
        updateStatus(item.children, circularArray);
      }
    });
    return jsonArray
}

module.exports = {CircularArray, updateStatus};