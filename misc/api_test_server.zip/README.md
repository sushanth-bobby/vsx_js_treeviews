# API Test Server


### CURL commands for /post
```
curl -X POST -H "Content-Type: application/json" -d "{\"message\":\"Hello, World!\"}" http://localhost:3100/post

curl -X POST -H "Content-Type: text/plain" -d "Hello, World!" http://localhost:3100/post

```

### CURL commands for /login
```
curl -X POST -H "Content-Type: application/json" -d "{\"username\":\"admin\", \"password\":\"admin\"}" http://localhost:3100/login
```