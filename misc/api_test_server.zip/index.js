// Import the necessary modules
const express = require('express');
const path = require('path');
const fs   = require('fs');
// const jwt = require('jsonwebtoken');

const {CircularArray, updateStatus} = require("./helpers/circularArray.js");

// Initializations
const app = express();
const port = 3100;

// Dummy user for demonstration (in a real application, you would use a database)
const dummyUser = {
    username: 'admin',
    password: 'admin'  
};
// Secret key for JWT signing
// const secretKey = 'your_secret_key';


// Functions
let getDate = () => {
    let date_time = new Date();

    // get current date
    // adjust 0 before single digit date
    let date = ("0" + date_time.getDate()).slice(-2);
    
    // get current month
    let month = ("0" + (date_time.getMonth() + 1)).slice(-2);
    
    // get current year
    let year = date_time.getFullYear();
    
    // get current hours
    let hours = date_time.getHours();
    
    // get current minutes
    let minutes = date_time.getMinutes();
    
    // get current seconds
    let seconds = date_time.getSeconds();
    
    // prints date in YYYY-MM-DD format
    // console.log(year + "-" + month + "-" + date);
    
    // prints date & time in YYYY-MM-DD HH:MM:SS format
    let ts = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
    return ts
}

// Middleware
app.use((req, res, next) => {
    console.log(`${getDate()} : ${req.method} : ${req.originalUrl}`)
    next()
})

// Middleware to parse JSON bodies
app.use(express.json());
// Middleware to parse plain text bodies
app.use(express.text());


// Routes
// -----------------------------------------------------------------------------
// (1): Route to return JSON data
app.get('/json', (req, res) => {
    // Define a sample JSON object
    const jsonData = {
        message: 'Hello, this is a JSON response!',
        status: 'success',
        data: {
            name: 'John Doe',
            age: 30,
            hobbies: ['reading', 'traveling', 'coding']
        }
    };
    // Send the JSON response
    res.json(jsonData);
});

// -----------------------------------------------------------------------------
// (2): Route to return plain text data
app.get('/text', (req, res) => {

    const textData = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, \nsed do eiusmod tempor incididunt ut labore et dolore magna aliqua. \nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris \nnisi ut aliquip ex ea commodo consequat. \n\nDuis aute irure dolor in reprehenderit in \nvoluptate velit esse cillum dolore eu fugiat nulla pariatur. \nExcepteur sint occaecat cupidatat non proident, \nsunt in culpa qui officia deserunt mollit anim id est laborum.";

    // Send the plain text response
    res.type('text').send(textData);
});

// -----------------------------------------------------------------------------
// (3): Route to return array of JSON data
app.get('/arrjson1', (req, res) => {
    // Read JSON from ./data
    let fileContent = fs.readFileSync(path.join(__dirname, 'data', 'arrOfJson.json'), 'utf8');

    // Send the JSON response
    // res.json(JSON.parse(fileContent))

    // Sending delayted response
    setTimeout( () => {
        res.json(JSON.parse(fileContent))
    }, 8000);
});

// -----------------------------------------------------------------------------
// (4): Route to post data
app.post('/post', (req, res) => {
    const data = req.body;
    // console.log(`data: ${JSON.stringify(data)}`)
    // console.log(`${JSON.stringify(req)}`)

    let receivedData = {
        data: null,
        type: null,
    };

    receivedData.type = req.headers['content-type'];
    if (typeof req.body === 'object' && req.is('application/json')) {
        // Handle JSON data
        // console.log("JSON")
        receivedData.data = JSON.stringify(data);
    } else if (typeof req.body === 'string' && req.is('text/plain')) {
        // Handle plain text data
        // console.log("TEXT")
        receivedData.data = data;
    }

    console.log(`Received Datatype: ${receivedData.type}`)
    console.log(`Received Data: \n----------\n${receivedData.data}\n----------`)

  // Send a response to client that will show that the request was successfull.
  res.send({
    message: 'Message received',
  });
});

// -----------------------------------------------------------------------------
// (5): Route to poll and return array of JSON data
app.get('/poll', (req, res) => {

    const statusArray = new CircularArray(["in-progress", "success", "failure"]);

    // Read JSON from ./data    
    let fileContent = fs.readFileSync(path.join(__dirname, 'data', 'arrOfJson.json'), 'utf8');
    
    fileContent = updateStatus(JSON.parse(fileContent), statusArray);

    fs.writeFileSync(path.join(__dirname, 'data', 'arrOfJson.json'), JSON.stringify(fileContent, null, 3), 'utf8');

    res.json(fileContent)
});

// -----------------------------------------------------------------------------
// (6): login route accepts username and password
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Check if username and password match the dummy user
    if (username === dummyUser.username && password === dummyUser.password) {
        // User authenticated, generate a JWT token
        // const token = jwt.sign({ username }, secretKey, { expiresIn: '1h' });
        let temp = username+':'+password
        const token = Buffer.from(temp).toString('base64');

        // Return the token to the client
        res.json({ token });
    } else {
        // Authentication failed
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

// -----------------------------------------------------------------------------
// (-): Start the server and listen on the defined port
app.listen(port, () => {
    console.log(`Express app listening at http://localhost:${port}`);
});
